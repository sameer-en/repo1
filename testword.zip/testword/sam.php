<?php 
error_reporting(-1);
require_once('PHPWord-develop/vendor/autoload.php');
// \PhpOffice\PhpWord\Autoloader::register();

use PhpOffice\PhpWord\PhpWord;


$name = basename(__FILE__, '.php');
$source = __DIR__ . "/{$name}.docx";

// echo date('H:i:s'), " Reading contents from `{$source}`", EOL;
$phpWord = \PhpOffice\PhpWord\IOFactory::load($source);
// Save file
echo '>>';var_dump($phpWord->save($phpWord, '111', 'Word2007'));


die;
// use PhpOffice\PhpWord\Style\Font;
// Creating the new document...
$phpWord = new \PhpOffice\PhpWord\PhpWord();
$section = $phpWord->addSection();
/* Note: any element you append to a document must reside inside of a Section. 


Note: it's possible to customize font style of the Text element you add in     three ways:
- inline;
- using named font style (new font style object will be implicitly created);
- using explicitly created font style object. */
// Adding Text element with font customized inline...
$section->addText(
htmlspecialchars(
'"Great achievement is usually born of great sacrifice, '
. 'and is never the result of selfishness." '
. '(Napoleon Hill)'
),
array('name' => 'Tahoma', 'size' => 10)
);

// Adding Text element with font customized using named font style...
$fontStyleName = 'oneUserDefinedStyle';
$phpWord->addFontStyle(
$fontStyleName,
array('name' => 'Tahoma', 'size' => 10, 'color' => '1B2232', 'bold' => true)
);
$section->addText(
htmlspecialchars(
'"The greatest accomplishment is not in never falling, '
. 'but in rising again after you fall." '
. '(Vince Lombardi)'
),
$fontStyleName
);

// Adding Text element with font customized using explicitly created font      style object...
$fontStyle = new \PhpOffice\PhpWord\Style\Font();
$fontStyle->setBold(true);
$fontStyle->setName('Tahoma');
$fontStyle->setSize(13);
$myTextElement = $section->addText(
htmlspecialchars('"Believe you can and you\'re halfway there." (Theodor    Roosevelt)')
);
$myTextElement->setFontStyle($fontStyle);

// Saving the document as OOXML file...
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
$objWriter->save(dirname(__FILE__).'helloWorld.docx');
echo '<pre>';print_r($objWriter);die('123');

// Saving the document as ODF file...
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'ODText');
 $objWriter->save('helloWorld.odt');

// Saving the document as HTML file...
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'HTML');
$objWriter->save('helloWorld.html');
echo "Complete";
?>